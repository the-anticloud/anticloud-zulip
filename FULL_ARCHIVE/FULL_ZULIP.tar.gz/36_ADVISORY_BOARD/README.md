# 36 Advisory Board

**Project:** ZULIP
**Upstream:** https://github.com/zulip/zulip

Content specific to ZULIP in category CHAT_PLATFORMS.
