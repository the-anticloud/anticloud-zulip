# Command Line Interface — ZULIP

**Upstream:** https://github.com/zulip/zulip

## Anticloud CLI

```bash
# Install
pip install anticloud-zulip

# Run offline with PAX inference
anticloud-zulip --offline --pax-local

# Run with AIOSS logging
anticloud-zulip --aioss-log ./ledger.jsonl

# Single binary (after build)
./zulip --config config.yaml
```

## Options

| Flag | Description |
| --- | --- |
| `--offline` | Disable all network calls |
| `--pax-local` | Use local PAX inference at 127.0.0.1:11434 |
| `--aioss-log PATH` | Write AIOSS audit chain to PATH |
| `--encrypt` | Enable AES-256 at rest for output files |
| `--gpu` | Force GPU inference |
| `--cpu` | Force CPU inference |
| `--config PATH` | Load configuration from YAML file |
